#### Instalar o projeto

* Instalar as dependências
```
npm i
```

* Rodar Api
```
npm run api
```

* Rodar o Projeto
```
npm run dev
```

#### Preview
<img src="./preview/home.png" alt="">
<br />
<img src="./preview/todos.png" alt="">

* Base
```
https://luxe-7bfed1fd.base44.app/
```